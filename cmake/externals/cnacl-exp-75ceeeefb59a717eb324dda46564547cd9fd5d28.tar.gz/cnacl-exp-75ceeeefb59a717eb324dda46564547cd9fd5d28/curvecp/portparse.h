#ifndef PORTPARSE_H
#define PORTPARSE_H

extern int portparse(unsigned char *,const char *);

#endif
