#ifndef BYTE_H
#define BYTE_H

extern void byte_zero(void *,long long);
extern void byte_copy(void *,long long,const void *);
extern int byte_isequal(const void *,long long,const void *);

#endif
