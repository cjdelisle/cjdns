#ifndef NAMEPARSE_H
#define NAMEPARSE_H

extern int nameparse(unsigned char *,const char *);

#endif
