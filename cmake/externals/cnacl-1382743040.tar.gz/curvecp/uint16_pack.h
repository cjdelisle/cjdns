#ifndef UINT16_PACK_H
#define UINT16_PACK_H

#include "crypto_uint16.h"

extern void uint16_pack(unsigned char *,crypto_uint16);

#endif
