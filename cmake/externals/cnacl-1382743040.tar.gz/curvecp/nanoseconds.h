#ifndef NANOSECONDS_H
#define NANOSECONDS_H

extern long long nanoseconds(void);

#endif
