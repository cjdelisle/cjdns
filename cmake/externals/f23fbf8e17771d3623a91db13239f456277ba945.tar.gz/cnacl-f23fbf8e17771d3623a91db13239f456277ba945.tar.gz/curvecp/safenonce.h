#ifndef SAFENONCE_H
#define SAFENONCE_H

extern int safenonce(unsigned char *,int);

#endif
