#include <stdio.h>

main()
{
  printf("unknown CPU ID\n");
  return 0;
}
