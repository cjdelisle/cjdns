#include "crypto_uint64.h"
#include "unsigned.h"
DOIT(64,crypto_uint64)
