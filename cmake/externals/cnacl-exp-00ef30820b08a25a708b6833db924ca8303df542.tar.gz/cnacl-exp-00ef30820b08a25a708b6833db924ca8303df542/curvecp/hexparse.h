#ifndef HEXPARSE_H
#define HEXPARSE_H

extern int hexparse(unsigned char *,long long,const char *);

#endif
