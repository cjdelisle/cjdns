#ifndef crypto_sign_ed25519_H
#define crypto_sign_ed25519_H

#define crypto_sign_ed25519_amd64-64-24k_SECRETKEYBYTES 64
#define crypto_sign_ed25519_amd64-64-24k_PUBLICKEYBYTES 32
#define crypto_sign_ed25519_amd64-64-24k_BYTES 64
#ifdef __cplusplus
#include <string>
extern std::string crypto_sign_ed25519_amd64-64-24k(const std::string &,const std::string &);
extern std::string crypto_sign_ed25519_amd64-64-24k_open(const std::string &,const std::string &);
extern std::string crypto_sign_ed25519_amd64-64-24k_keypair(std::string *);
extern "C" {
#endif
extern int crypto_sign_ed25519_amd64-64-24k(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_ed25519_amd64-64-24k_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_ed25519_amd64-64-24k_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif
#define crypto_sign_ed25519 crypto_sign_ed25519_amd64-64-24k
#define crypto_sign_ed25519_open crypto_sign_ed25519_amd64-64-24k_open
#define crypto_sign_ed25519_keypair crypto_sign_ed25519_amd64-64-24k_keypair
#define crypto_sign_ed25519_BYTES crypto_sign_ed25519_amd64-64-24k_BYTES
#define crypto_sign_ed25519_PUBLICKEYBYTES crypto_sign_ed25519_amd64-64-24k_PUBLICKEYBYTES
#define crypto_sign_ed25519_SECRETKEYBYTES crypto_sign_ed25519_amd64-64-24k_SECRETKEYBYTES
#define crypto_sign_ed25519_IMPLEMENTATION "crypto_sign/ed25519/amd64-64-24k"
#ifndef crypto_sign_ed25519_amd64-64-24k_VERSION
#define crypto_sign_ed25519_amd64-64-24k_VERSION "-"
#endif
#define crypto_sign_ed25519_VERSION crypto_sign_ed25519_amd64-64-24k_VERSION

#endif
